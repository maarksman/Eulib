The html web addresses of importance are:

http://betaweb.csug.rochester.edu/~jfreeze/URpedia/milestone3/taskA/www/show_relations.html

http://betaweb.csug.rochester.edu/~jfreeze/URpedia/milestone3/taskA/www/Login.html

http://betaweb.csug.rochester.edu/~jfreeze/URpedia/milestone3/taskA/www/Signup.html

http://betaweb.csug.rochester.edu/~jfreeze/URpedia/milestone3/taskA/www/MainScreen.html

The last three demonstrate our current interface. At this time there is only database connectivity in the buttons for showing relations on the Mainscreen.html page. 
The trending, categories, and article sections will be populated with database connectivity in the future. The login and signup pages verify that you enter input into
the fields but do not currently check against the database for validation or creation of new users. 
