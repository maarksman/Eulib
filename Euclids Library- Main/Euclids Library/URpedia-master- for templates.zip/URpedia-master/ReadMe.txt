Project 1 Part 3 ReadMe.

We created a python script to generate random user, article and field data to populate our URpedia database. The script generated 5 txt files with table data. We put these files into the Article, Field, Has_Experience, User, and Admin tables. Each table's structure is specified in the create.sql file. 

Article carries information for each article on the website. Field has information of possible topics like chemistry or math. Has_Experience holds info on user experience. User holds the information on the users. Admin holds information on the subset of users who are admins. 

The tables are almost identical to what we specified in project 1 parts 1 and 2. The only minor differences are changing the lengths of some varchar elements and changing a few identifications from varchars or chars into ints.

