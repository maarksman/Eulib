db.items.remove({'Seller._Rating':{$lt:0}})
