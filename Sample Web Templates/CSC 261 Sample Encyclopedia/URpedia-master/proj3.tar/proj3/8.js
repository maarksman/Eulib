db.items.insert({_id:'88888888',Name:'World War I Canadian Flag from the Somme','Category':['History','WWI'],'Number_of_Bids':0})

