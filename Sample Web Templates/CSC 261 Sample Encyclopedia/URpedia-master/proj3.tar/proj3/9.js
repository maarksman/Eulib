 db.items.update({_id:'1678348584'},{$set:{'Number_of_Bids':'1','Bids.Bid':{'Bidder':{'_id':'mimiyaya'},'Time':'Dec-07-01 04:56:27','Amount':'1000'}}})
